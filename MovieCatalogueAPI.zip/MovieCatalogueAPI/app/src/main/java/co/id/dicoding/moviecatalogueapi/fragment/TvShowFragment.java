package co.id.dicoding.moviecatalogueapi.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;

import co.id.dicoding.moviecatalogueapi.BuildConfig;
import co.id.dicoding.moviecatalogueapi.R;
import co.id.dicoding.moviecatalogueapi.adapter.TvShowAdapter;
import co.id.dicoding.moviecatalogueapi.api.ApiClient;
import co.id.dicoding.moviecatalogueapi.constant.Constant;
import co.id.dicoding.moviecatalogueapi.model.TvShow;
import co.id.dicoding.moviecatalogueapi.rest.ListTvShowResponse;
import co.id.dicoding.moviecatalogueapi.util.LanguageUtil;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TvShowFragment extends Fragment {

    private RecyclerView rvTvsShow;
    private ArrayList<TvShow> tvShows;
    private ProgressBar progressBar;
    private GifImageView gifImageView;
    public static final String TAG = TvShowFragment.class.getSimpleName();
    private LanguageUtil languageUtil = new LanguageUtil();
    private String lang;
    String apiKey = BuildConfig.TMDB_API_KEY;

    public TvShowFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tv_show, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressBar = view.findViewById(R.id.progressBarTvShow);
        gifImageView = view.findViewById(R.id.gifloadtv);
        rvTvsShow = view.findViewById(R.id.rv_tv_show);
        rvTvsShow.setHasFixedSize(true);
        Log.d(TAG, "onCreate: " + languageUtil.getPrefLanguage(getActivity()));
        lang = languageUtil.getPrefLanguage(getActivity());
        if (savedInstanceState != null) {
            tvShows = savedInstanceState.getParcelableArrayList(Constant.STATE_RESULT);
            showTvShowList(tvShows);
        } else {
            getTvShows();
        }
    }

    private void getTvShows() {
        showLoading(true);
        final Call<ListTvShowResponse> tvs = ApiClient.getApi().getTvShows(
                apiKey,
                lang.equals("en") ? Constant.API_LANG_ENGLISH : Constant.API_LANG_INDONESIAN);
        tvs.enqueue(new Callback<ListTvShowResponse>() {
            @Override
            public void onResponse(Call<ListTvShowResponse> call, Response<ListTvShowResponse> response) {
                Log.d(TAG, "onResponse: first tv show is " + response.body().getResults().get(0).getName());
                showLoading(false);
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        tvShows = response.body().getResults();
                        showTvShowList(tvShows);
                    }
                } else {
                    Toast.makeText(getActivity(), R.string.notif_error_get_data, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ListTvShowResponse> call, Throwable t) {
                showLoading(false);
                Log.d(TAG, "onFailure: " + t.toString());
            }
        });
    }

    private void showTvShowList(ArrayList<TvShow> tvs) {
        rvTvsShow.setLayoutManager(new LinearLayoutManager(getActivity()));
        TvShowAdapter tvShowAdapter = new TvShowAdapter(tvs, getActivity());
        rvTvsShow.setAdapter(tvShowAdapter);
    }

    private void showLoading(Boolean state) {
        if (state) {
//            progressBar.setVisibility(View.VISIBLE);
            gifImageView.setVisibility(View.VISIBLE);
        } else {
//            progressBar.setVisibility(View.GONE);
            gifImageView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(Constant.STATE_RESULT, tvShows);
    }
}
