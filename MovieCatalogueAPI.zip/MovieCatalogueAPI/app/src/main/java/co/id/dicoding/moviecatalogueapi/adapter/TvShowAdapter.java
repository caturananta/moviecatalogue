package co.id.dicoding.moviecatalogueapi.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import co.id.dicoding.moviecatalogueapi.R;
import co.id.dicoding.moviecatalogueapi.activity.DetailActivity;
import co.id.dicoding.moviecatalogueapi.constant.Constant;
import co.id.dicoding.moviecatalogueapi.model.TvShow;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.TvShowViewsHolder> {

    private ArrayList<TvShow> listTvShow;
    private Context mContext;

    public TvShowAdapter(ArrayList<TvShow> list, Context context) {
        this.listTvShow = list;
        this.mContext = context;
    }

    @NonNull
    @Override
    public TvShowViewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tv_show, viewGroup, false);
        return new TvShowAdapter.TvShowViewsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TvShowViewsHolder tvShowViewsHolder, int i) {
        final TvShow tvShow = listTvShow.get(i);
        String errTranslate = tvShowViewsHolder.itemView.getContext().getString(R.string.notif_err_translate);
        tvShowViewsHolder.tvTitle.setText(tvShow.getName());
        tvShowViewsHolder.tvYear.setText(tvShow.getFirst_air_date().split("-")[0]);
        tvShowViewsHolder.tvRating.setText(tvShow.getVote_average().toString());
        tvShowViewsHolder.tvDescr.setText(tvShow.getOverview().equals("") ? errTranslate : tvShow.getOverview());
        Glide.with(tvShowViewsHolder.itemView.getContext())
                .load(Constant.POSTER_URL + tvShow.getPoster_path())
                .into(tvShowViewsHolder.tvPoster);

        tvShowViewsHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailMovie = new Intent(mContext, DetailActivity.class);
                detailMovie.putExtra(Constant.EXTRA_DATA, tvShow);
                detailMovie.putExtra(Constant.EXTRA_FLAG, Constant.FLAG_TVSHOW);
                mContext.startActivity(detailMovie);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listTvShow.size();
    }

    public class TvShowViewsHolder extends RecyclerView.ViewHolder {
        ImageView tvPoster;
        TextView tvTitle, tvRating, tvDescr, tvYear;

        public TvShowViewsHolder(@NonNull View itemView) {
            super(itemView);
            tvPoster = itemView.findViewById(R.id.img_tv_photo);
            tvTitle = itemView.findViewById(R.id.txt_tv_name);
            tvYear = itemView.findViewById(R.id.txt_tv_year);
            tvRating = itemView.findViewById(R.id.txt_tv_rating);
            tvDescr = itemView.findViewById(R.id.txt_tv_description);
        }
    }
}
