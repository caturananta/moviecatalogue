package co.id.dicoding.moviecatalogueapi.constant;

public interface Constant {

    String EXTRA_DATA = "extra_data";
    String EXTRA_FLAG = "extra_flag";
    String EXTRA_STATE = "extra_state";
    String EXTRA_POSITION = "extra_position";
    String FLAG_MOVIE = "movie";
    String FLAG_FAVORITE = "favorite";
    String FLAG_TVSHOW = "tvshow";
    String KEY_LANG_ID = "in";
    String KEY_LANG_EN = "en";
    String API_LANG_INDONESIAN = "id";
    String API_LANG_ENGLISH = "en-USA";
    String POSTER_URL = "https://image.tmdb.org/t/p/original";
    String STATE_RESULT = "state_result";
}
