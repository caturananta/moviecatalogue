package co.id.dicoding.moviecatalogueapi.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;

import co.id.dicoding.moviecatalogueapi.BuildConfig;
import co.id.dicoding.moviecatalogueapi.R;
import co.id.dicoding.moviecatalogueapi.adapter.MovieAdapter;
import co.id.dicoding.moviecatalogueapi.api.ApiClient;
import co.id.dicoding.moviecatalogueapi.constant.Constant;
import co.id.dicoding.moviecatalogueapi.model.Movie;
import co.id.dicoding.moviecatalogueapi.rest.ListMovieResponse;
import co.id.dicoding.moviecatalogueapi.util.LanguageUtil;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MovieFragment extends Fragment {

    private RecyclerView rvMovies;
    private ArrayList<Movie> arrMovie;
    private ProgressBar progressBar;
    private GifImageView gifImageView;
    public static final String TAG = MovieFragment.class.getSimpleName();
    private LanguageUtil languageUtil = new LanguageUtil();
    private String lang;
    String apiKey = BuildConfig.TMDB_API_KEY;

    public MovieFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_movie, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressBar = view.findViewById(R.id.progressBarMovie);
        gifImageView = view.findViewById(R.id.gifload);
        rvMovies = view.findViewById(R.id.rv_movies);
        rvMovies.setHasFixedSize(true);
        Log.d(TAG, "onCreate: " + languageUtil.getPrefLanguage(getActivity()));
        lang = languageUtil.getPrefLanguage(getActivity());
        if (savedInstanceState != null) {
            arrMovie = savedInstanceState.getParcelableArrayList(Constant.STATE_RESULT);
            showMovieList(arrMovie);
        } else {
            getMovies();
        }
    }

    private void getMovies() {
        showLoading(true);
        Call<ListMovieResponse> movies = ApiClient.getApi().getMovies(
                apiKey,
                lang.equals("en") ? Constant.API_LANG_ENGLISH : Constant.API_LANG_INDONESIAN);
        movies.enqueue(new Callback<ListMovieResponse>() {
            @Override
            public void onResponse(Call<ListMovieResponse> call, Response<ListMovieResponse> response) {
                showLoading(false);
                Log.d(TAG, "onResponse: first movie is " + response.body().getResults().get(0).getId());
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        arrMovie = response.body().getResults();
                        showMovieList(arrMovie);
                    }
                } else {
                    Toast.makeText(getActivity(), R.string.notif_error_get_data, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ListMovieResponse> call, Throwable t) {
                showLoading(false);
                Log.d(TAG, "onFailure: " + t.toString());
            }
        });
    }

    private void showMovieList(ArrayList<Movie> movies) {
        rvMovies.setLayoutManager(new LinearLayoutManager(getActivity()));
        MovieAdapter movieAdapter = new MovieAdapter(movies, getActivity());
        rvMovies.setAdapter(movieAdapter);
    }

    private void showLoading(Boolean state) {
        if (state) {
//            progressBar.setVisibility(View.VISIBLE);
            gifImageView.setVisibility(View.VISIBLE);
        } else {
//            progressBar.setVisibility(View.GONE);
            gifImageView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(Constant.STATE_RESULT, arrMovie);
    }
}
